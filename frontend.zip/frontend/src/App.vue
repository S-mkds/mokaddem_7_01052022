<script>
export default {
  name: "App",
}
</script>

<template>
  <router-view></router-view>
</template>

<style>
p {
  color: white !important;
}
h {
  color: white !important;
}
body {
 background-color: #FFD7D7 !important;
}
</style>
